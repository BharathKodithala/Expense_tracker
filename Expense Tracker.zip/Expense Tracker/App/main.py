import sqlite3
import tkinter as tk
from tkinter import ttk, messagebox
import re
from datetime import datetime

class ExpenseTracker:
    def __init__(self, root):
        self.root = root
        self.root.title("Expense Tracker with Stock Investments")
        self.root.geometry("900x600")

        # Database setup
        self.conn = sqlite3.connect("expense_tracker.db")
        self.cursor = self.conn.cursor()
        self.create_table()

        # Configure styles
        self.configure_styles()

        # Build UI
        self.create_widgets()

        # Initial data load
        self.view_expenses()

        # Handle window closing
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)

    def configure_styles(self):
        style = ttk.Style()
        style.configure('TFrame', background='#f0f0f0')
        style.configure('TLabel', background='#f0f0f0', font=('Arial', 10))
        style.configure('TButton', font=('Arial', 10))
        style.configure('Stock.TLabel', background='#f0f0f0', foreground='blue', font=('Arial', 10, 'bold'))
        style.configure('Stock.TEntry', foreground='blue', font=('Arial', 10))
        style.configure('Treeview', font=('Arial', 10), rowheight=25)
        style.configure('Treeview.Heading', font=('Arial', 10, 'bold'))

    def create_table(self):
        self.cursor.execute("""
        CREATE TABLE IF NOT EXISTS expenses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            amount REAL NOT NULL,
            category TEXT NOT NULL,
            description TEXT,
            date TEXT NOT NULL,
            stock_name TEXT,
            shares INTEGER,
            price_per_share REAL
        )
        """)
        self.conn.commit()

    def create_widgets(self):
        # Main container
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Add Expense Frame
        add_frame = ttk.LabelFrame(main_frame, text="Add Expense")
        add_frame.pack(fill=tk.X, padx=5, pady=5)

        # Category selection
        ttk.Label(add_frame, text="Category:").grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        self.categories = ["Food", "Transport", "Housing", "Entertainment", "Stock Investment"]
        self.category_var = tk.StringVar()
        self.category_combobox = ttk.Combobox(add_frame, textvariable=self.category_var,
                                              values=self.categories, state="readonly")
        self.category_combobox.grid(row=0, column=1, padx=5, pady=5, sticky=tk.EW)
        self.category_combobox.bind("<<ComboboxSelected>>", self.toggle_stock_fields)

        # Amount
        ttk.Label(add_frame, text="Amount:").grid(row=1, column=0, padx=5, pady=5, sticky=tk.W)
        self.amount_entry = ttk.Entry(add_frame)
        self.amount_entry.grid(row=1, column=1, padx=5, pady=5, sticky=tk.EW)

        # Description
        ttk.Label(add_frame, text="Description:").grid(row=2, column=0, padx=5, pady=5, sticky=tk.W)
        self.description_entry = ttk.Entry(add_frame)
        self.description_entry.grid(row=2, column=1, padx=5, pady=5, sticky=tk.EW)

        # Date
        ttk.Label(add_frame, text="Date (DD-MM-YYYY):").grid(row=3, column=0, padx=5, pady=5, sticky=tk.W)
        self.date_entry = ttk.Entry(add_frame)
        self.date_entry.grid(row=3, column=1, padx=5, pady=5, sticky=tk.EW)
        self.date_entry.insert(0, datetime.now().strftime("%d-%m-%Y"))

        # Stock-specific fields (initially hidden)
        self.stock_frame = ttk.Frame(add_frame)
        self.stock_frame.grid(row=4, column=0, columnspan=2, sticky=tk.EW, padx=5, pady=5)

        ttk.Label(self.stock_frame, text="Stock Name:", style='Stock.TLabel').grid(row=0, column=0, padx=5, pady=2, sticky=tk.W)
        self.stock_name_entry = ttk.Entry(self.stock_frame, style='Stock.TEntry')
        self.stock_name_entry.grid(row=0, column=1, padx=5, pady=2, sticky=tk.EW)

        ttk.Label(self.stock_frame, text="Shares:", style='Stock.TLabel').grid(row=1, column=0, padx=5, pady=2, sticky=tk.W)
        self.shares_entry = ttk.Entry(self.stock_frame, style='Stock.TEntry')
        self.shares_entry.grid(row=1, column=1, padx=5, pady=2, sticky=tk.EW)

        ttk.Label(self.stock_frame, text="Price per Share:", style='Stock.TLabel').grid(row=2, column=0, padx=5, pady=2, sticky=tk.W)
        self.price_per_share_entry = ttk.Entry(self.stock_frame, style='Stock.TEntry')
        self.price_per_share_entry.grid(row=2, column=1, padx=5, pady=2, sticky=tk.EW)

        # Initially hide stock fields
        self.stock_frame.grid_remove()

        # Add button
        ttk.Button(add_frame, text="Add Expense", command=self.add_expense).grid(row=5, column=0, columnspan=2, pady=10)

        # View Expenses Frame
        view_frame = ttk.LabelFrame(main_frame, text="Expenses")
        view_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Treeview with scrollbars
        self.tree_frame = ttk.Frame(view_frame)
        self.tree_frame.pack(fill=tk.BOTH, expand=True)

        self.tree_scroll_y = ttk.Scrollbar(self.tree_frame)
        self.tree_scroll_y.pack(side=tk.RIGHT, fill=tk.Y)

        self.tree_scroll_x = ttk.Scrollbar(self.tree_frame, orient=tk.HORIZONTAL)
        self.tree_scroll_x.pack(side=tk.BOTTOM, fill=tk.X)

        columns = ("ID", "Amount", "Category", "Description", "Date", "Stock Name", "Shares", "Price per Share")
        self.tree = ttk.Treeview(self.tree_frame, columns=columns, show="headings",
                                 yscrollcommand=self.tree_scroll_y.set,
                                 xscrollcommand=self.tree_scroll_x.set)
        self.tree.pack(fill=tk.BOTH, expand=True)

        self.tree_scroll_y.config(command=self.tree.yview)
        self.tree_scroll_x.config(command=self.tree.xview)

        for col in columns:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=100, anchor=tk.CENTER)

        # Buttons Frame
        buttons_frame = ttk.Frame(view_frame)
        buttons_frame.pack(fill=tk.X, padx=5, pady=5)

        ttk.Button(buttons_frame, text="Delete Expense", command=self.delete_expense).pack(side=tk.LEFT, padx=5)
        ttk.Button(buttons_frame, text="Clear All", command=self.clear_form).pack(side=tk.LEFT, padx=5)

    def toggle_stock_fields(self, event=None):
        if self.category_var.get() == "Stock Investment":
            self.stock_frame.grid()
            self.amount_entry.config(state='disabled')
            self.amount_entry.delete(0, tk.END)
            self.stock_name_entry.focus()
        else:
            self.stock_frame.grid_remove()
            self.amount_entry.config(state='normal')

    def validate_fields(self):
        # Validate date format
        date_str = self.date_entry.get()
        try:
            datetime.strptime(date_str, "%d-%m-%Y")
        except ValueError:
            messagebox.showerror("Error", "Invalid date format. Please use DD-MM-YYYY.")
            return False

        # Validate category
        if not self.category_var.get():
            messagebox.showerror("Error", "Please select a category")
            return False

        # Validate amount or stock fields
        if self.category_var.get() == "Stock Investment":
            try:
                shares = float(self.shares_entry.get())
                price = float(self.price_per_share_entry.get())
                if shares <= 0 or price <= 0:
                    raise ValueError("Positive values required")
                if not self.stock_name_entry.get().strip():
                    raise ValueError("Stock name required")
            except ValueError as e:
                messagebox.showerror("Error", f"Invalid stock data: {e}")
                return False
        else:
            try:
                amount = float(self.amount_entry.get())
                if amount <= 0:
                    raise ValueError("Positive amount required")
            except ValueError as e:
                messagebox.showerror("Error", f"Invalid amount: {e}")
                return False

        return True

    def add_expense(self):
        if not self.validate_fields():
            return

        try:
            category = self.category_var.get()
            description = self.description_entry.get()
            date = self.date_entry.get()

            if category == "Stock Investment":
                stock_name = self.stock_name_entry.get().strip()
                shares = float(self.shares_entry.get())
                price_per_share = float(self.price_per_share_entry.get())
                amount = shares * price_per_share
            else:
                stock_name = None
                shares = None
                price_per_share = None
                amount = float(self.amount_entry.get())

            self.cursor.execute("""
                INSERT INTO expenses 
                (amount, category, description, date, stock_name, shares, price_per_share) 
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (amount, category, description, date, stock_name, shares, price_per_share))

            self.conn.commit()
            messagebox.showinfo("Success", "Expense added successfully!")
            self.view_expenses()
            self.clear_form()

        except Exception as e:
            messagebox.showerror("Error", f"Could not add expense: {e}")

    def view_expenses(self):
        for row in self.tree.get_children():
            self.tree.delete(row)

        self.cursor.execute("SELECT * FROM expenses ORDER BY date DESC")
        rows = self.cursor.fetchall()

        for row in rows:
            self.tree.insert("", tk.END, values=row)

    def delete_expense(self):
        selected_item = self.tree.selection()
        if not selected_item:
            messagebox.showwarning("Warning", "No expense selected.")
            return

        expense_id = self.tree.item(selected_item)["values"][0]

        if messagebox.askyesno("Confirm", "Delete this expense?"):
            self.cursor.execute("DELETE FROM expenses WHERE id = ?", (expense_id,))
            self.conn.commit()
            self.view_expenses()
            messagebox.showinfo("Success", "Expense deleted successfully!")

    def clear_form(self):
        self.category_var.set('')
        self.amount_entry.config(state='normal')
        self.amount_entry.delete(0, tk.END)
        self.description_entry.delete(0, tk.END)
        self.date_entry.delete(0, tk.END)
        self.date_entry.insert(0, datetime.now().strftime("%d-%m-%Y"))
        self.stock_name_entry.delete(0, tk.END)
        self.shares_entry.delete(0, tk.END)
        self.price_per_share_entry.delete(0, tk.END)
        self.stock_frame.grid_remove()

    def on_closing(self):
        if messagebox.askokcancel("Quit", "Do you want to quit?"):
            self.conn.close()
            self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = ExpenseTracker(root)
    root.mainloop()
